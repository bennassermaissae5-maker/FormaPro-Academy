# 🎓 FormaPro Academy – Centre de Formation

Site web complet développé avec **HTML/CSS/JS + PHP + MySQL**

---

## 🏗️ Architecture des fichiers

```
formation/
├── index.html              ← Page principale du site
├── admin/
│   └── index.html          ← Tableau de bord admin
├── css/
│   └── style.css           ← Feuille de style complète
├── js/
│   └── app.js              ← JavaScript frontend (AJAX, SPA-like)
├── php/
│   ├── config.php          ← Configuration + connexion PDO
│   ├── api_formations.php  ← API REST : formations, catégories, stats
│   ├── api_auth.php        ← API REST : inscription/connexion
│   └── api_inscriptions.php← API REST : inscriptions, contact
├── sql/
│   └── database.sql        ← Schéma MySQL + données de démo
└── assets/
    └── uploads/            ← Dossier pour les images uploadées
```

---

## ⚙️ Installation

### 1. Prérequis
- **Serveur web** : Apache ou Nginx avec PHP 8.1+
- **Base de données** : MySQL 8.0+ ou MariaDB 10.6+
- **Outils** : XAMPP / WAMP / MAMP ou serveur Linux

### 2. Cloner / placer les fichiers
```bash
# Copier le dossier dans votre répertoire web
cp -r formation/ /var/www/html/
# ou pour XAMPP :
cp -r formation/ C:/xampp/htdocs/
```

### 3. Créer la base de données
```bash
mysql -u root -p < sql/database.sql
```
Ou via phpMyAdmin : importer le fichier `sql/database.sql`

### 4. Configurer la connexion
Ouvrir `php/config.php` et modifier :
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'centre_formation');
define('DB_USER', 'votre_utilisateur');  // ← modifier
define('DB_PASS', 'votre_mot_de_passe'); // ← modifier
define('SITE_URL', 'http://localhost/formation');
```

### 5. Permissions
```bash
chmod 755 assets/uploads/
```

### 6. Accéder au site
- **Site public** : http://localhost/formation/
- **Admin** : http://localhost/formation/admin/

---

## 🔐 Compte admin par défaut
```
Email    : admin@formation.ma
Username : admin
```
> ⚠️ Pensez à changer le mot de passe admin en production via :
```php
password_hash('votre_nouveau_mdp', PASSWORD_BCRYPT, ['cost' => 12])
```

---

## 🗄️ Schéma de la base de données

| Table | Description |
|-------|-------------|
| `categories` | Domaines de formation |
| `formations` | Catalogue des formations |
| `formateurs` | Profils des formateurs |
| `sessions` | Sessions planifiées |
| `stagiaires` | Comptes des apprenants |
| `inscriptions` | Inscriptions aux sessions |
| `avis` | Évaluations des formations |
| `contacts` | Messages du formulaire |
| `admins` | Comptes administrateurs |

---

## 🌐 APIs disponibles

### `php/api_formations.php`
| Action | Méthode | Description |
|--------|---------|-------------|
| `list` | GET | Liste des formations (filtrée, paginée) |
| `detail` | GET | Détail d'une formation + sessions |
| `categories` | GET | Liste des catégories |
| `stats` | GET | Statistiques pour le hero |

### `php/api_auth.php`
| Action | Méthode | Description |
|--------|---------|-------------|
| `register` | POST | Création de compte |
| `login` | POST | Connexion |
| `logout` | GET | Déconnexion |
| `me` | GET | Utilisateur courant |

### `php/api_inscriptions.php`
| Action | Méthode | Description |
|--------|---------|-------------|
| `inscrire` | POST | S'inscrire à une session |
| `mes_inscriptions` | GET | Inscriptions de l'utilisateur |
| `contact` | POST | Envoyer un message |

---

## 🎨 Fonctionnalités

### Site public
- ✅ Page d'accueil avec hero animé et statistiques dynamiques
- ✅ Catalogue des formations filtrable par catégorie et niveau
- ✅ Recherche en temps réel (debounced)
- ✅ Pagination AJAX
- ✅ Modal de détail formation avec sessions disponibles
- ✅ Inscription aux sessions (auth requise)
- ✅ Authentification (inscription/connexion) en modal
- ✅ Section formateurs
- ✅ Témoignages
- ✅ Formulaire de contact
- ✅ Design responsive (mobile/tablette/desktop)
- ✅ Notifications toast

### Admin
- ✅ Dashboard avec statistiques
- ✅ Tableau des inscriptions récentes
- ✅ Liste des formations
- ✅ Interface sombre professionnelle

---

## 🔒 Sécurité implémentée
- Hashage bcrypt (cost 12) des mots de passe
- Requêtes préparées PDO (protection SQL injection)
- Échappement HTML (XSS)
- Sessions PHP sécurisées (httponly, samesite)
- Validation email côté serveur
- CSRF : ajouter un token pour la production

---

## 🚀 Évolutions possibles
- Paiement en ligne (CMI, PayPal, Stripe)
- Panel admin CRUD complet
- Espace apprenant (suivi de progression)
- Émission de certificats PDF
- Notifications email (PHPMailer)
- API mobile (React Native / Flutter)
