-- ============================================
--  CENTRE DE FORMATION - Schéma MySQL
-- ============================================

CREATE DATABASE IF NOT EXISTS centre_formation
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE centre_formation;

-- ----------------------------
-- Catégories de formations
-- ----------------------------
CREATE TABLE categories (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  nom       VARCHAR(100) NOT NULL,
  icone     VARCHAR(50)  DEFAULT 'book',
  couleur   VARCHAR(7)   DEFAULT '#2A6BA8',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Formateurs
-- ----------------------------
CREATE TABLE formateurs (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  prenom      VARCHAR(80)  NOT NULL,
  nom         VARCHAR(80)  NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  specialite  VARCHAR(150),
  bio         TEXT,
  photo_url   VARCHAR(255),
  actif       TINYINT(1)   DEFAULT 1,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Formations
-- ----------------------------
CREATE TABLE formations (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  categorie_id  INT          NOT NULL,
  formateur_id  INT,
  titre         VARCHAR(200) NOT NULL,
  description   TEXT,
  objectifs     TEXT,
  duree_heures  INT          DEFAULT 0,
  prix          DECIMAL(10,2) DEFAULT 0.00,
  niveau        ENUM('Débutant','Intermédiaire','Avancé') DEFAULT 'Débutant',
  places_max    INT          DEFAULT 20,
  image_url     VARCHAR(255),
  certifiante   TINYINT(1)   DEFAULT 0,
  active        TINYINT(1)   DEFAULT 1,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE CASCADE,
  FOREIGN KEY (formateur_id) REFERENCES formateurs(id) ON DELETE SET NULL
);

-- ----------------------------
-- Sessions de formation
-- ----------------------------
CREATE TABLE sessions (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  formation_id  INT NOT NULL,
  date_debut    DATE NOT NULL,
  date_fin      DATE NOT NULL,
  heure_debut   TIME DEFAULT '09:00:00',
  heure_fin     TIME DEFAULT '17:00:00',
  lieu          VARCHAR(200) DEFAULT 'En ligne',
  statut        ENUM('Planifiée','En cours','Terminée','Annulée') DEFAULT 'Planifiée',
  places_restantes INT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (formation_id) REFERENCES formations(id) ON DELETE CASCADE
);

-- ----------------------------
-- Stagiaires / Étudiants
-- ----------------------------
CREATE TABLE stagiaires (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  prenom      VARCHAR(80)  NOT NULL,
  nom         VARCHAR(80)  NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  telephone   VARCHAR(20),
  entreprise  VARCHAR(150),
  mot_de_passe VARCHAR(255) NOT NULL,
  actif       TINYINT(1)   DEFAULT 1,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Inscriptions
-- ----------------------------
CREATE TABLE inscriptions (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  stagiaire_id  INT NOT NULL,
  session_id    INT NOT NULL,
  date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  statut        ENUM('En attente','Confirmée','Annulée','Terminée') DEFAULT 'En attente',
  paiement      ENUM('Non payé','Payé','Remboursé') DEFAULT 'Non payé',
  montant       DECIMAL(10,2),
  UNIQUE KEY uniq_inscription (stagiaire_id, session_id),
  FOREIGN KEY (stagiaire_id) REFERENCES stagiaires(id) ON DELETE CASCADE,
  FOREIGN KEY (session_id)   REFERENCES sessions(id)   ON DELETE CASCADE
);

-- ----------------------------
-- Avis / Évaluations
-- ----------------------------
CREATE TABLE avis (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  formation_id  INT NOT NULL,
  stagiaire_id  INT NOT NULL,
  note          TINYINT CHECK (note BETWEEN 1 AND 5),
  commentaire   TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (formation_id) REFERENCES formations(id) ON DELETE CASCADE,
  FOREIGN KEY (stagiaire_id) REFERENCES stagiaires(id) ON DELETE CASCADE
);

-- ----------------------------
-- Messages de contact
-- ----------------------------
CREATE TABLE contacts (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nom        VARCHAR(150) NOT NULL,
  email      VARCHAR(150) NOT NULL,
  sujet      VARCHAR(200),
  message    TEXT NOT NULL,
  lu         TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Admins
-- ----------------------------
CREATE TABLE admins (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  username     VARCHAR(80)  NOT NULL UNIQUE,
  email        VARCHAR(150) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- DONNÉES DE DÉMONSTRATION
-- ============================================

INSERT INTO categories (nom, icone, couleur) VALUES
  ('Développement Web',   'code',        '#2563EB'),
  ('Cybersécurité',       'shield',      '#DC2626'),
  ('Data & IA',           'chart-bar',   '#7C3AED'),
  ('Cloud & DevOps',      'cloud',       '#0891B2'),
  ('Management',          'users',       '#059669'),
  ('Design UX/UI',        'palette',     '#F59E0B');

INSERT INTO formateurs (prenom, nom, email, specialite, bio) VALUES
  ('Karim',  'Benali',   'k.benali@formation.ma',   'Développement Web Full-Stack', 'Expert React/Node.js avec 10 ans d'expérience.'),
  ('Sanaa',  'El Fassi', 's.elfassi@formation.ma',  'Data Science & Machine Learning', 'PhD en IA, consultante pour plusieurs grandes entreprises.'),
  ('Youssef','Chraibi',  'y.chraibi@formation.ma',  'Cybersécurité & Réseaux', 'Certifié CISSP et CEH, ancien expert sécurité bancaire.'),
  ('Meryem', 'Tazi',     'm.tazi@formation.ma',     'Cloud AWS & DevOps', 'AWS Solutions Architect, spécialiste CI/CD.');

INSERT INTO formations (categorie_id, formateur_id, titre, description, objectifs, duree_heures, prix, niveau, places_max, certifiante) VALUES
  (1, 1, 'Développement Web Full-Stack (React + Node.js)',
   'Maîtrisez le développement web moderne de A à Z avec React.js et Node.js.',
   'Créer des applications web complètes, maîtriser les APIs REST, déployer sur le cloud.',
   80, 4500.00, 'Intermédiaire', 15, 1),
  (3, 2, 'Data Science avec Python',
   'Apprenez l''analyse de données, la visualisation et le Machine Learning.',
   'Analyser des datasets, créer des modèles ML, visualiser avec Matplotlib et Seaborn.',
   60, 3800.00, 'Débutant', 20, 1),
  (2, 3, 'Cybersécurité Fondamentaux',
   'Découvrez les bases de la sécurité informatique et la protection des systèmes.',
   'Identifier les vulnérabilités, mettre en place des politiques de sécurité.',
   40, 2900.00, 'Débutant', 18, 1),
  (4, 4, 'AWS Cloud Practitioner',
   'Préparez la certification AWS Cloud Practitioner et maîtrisez le cloud Amazon.',
   'Comprendre les services AWS, architecture cloud, sécurité et tarification.',
   35, 3200.00, 'Débutant', 20, 1),
  (5, 1, 'Management de Projet Agile (Scrum)',
   'Adoptez les méthodes agiles pour piloter vos projets efficacement.',
   'Maîtriser Scrum, animer des sprints, gérer un backlog produit.',
   24, 1800.00, 'Intermédiaire', 25, 1),
  (6, 2, 'Design UX/UI avec Figma',
   'Concevez des interfaces utilisateur modernes et intuitives avec Figma.',
   'Créer des maquettes, prototyper des interfaces, réaliser des tests utilisateurs.',
   30, 2200.00, 'Débutant', 15, 0);

INSERT INTO sessions (formation_id, date_debut, date_fin, lieu, statut, places_restantes) VALUES
  (1, '2026-05-05', '2026-07-18', 'Casablanca – Salle A', 'Planifiée', 8),
  (1, '2026-06-02', '2026-08-15', 'En ligne (Zoom)',       'Planifiée', 15),
  (2, '2026-05-12', '2026-06-20', 'Rabat – Salle B',       'Planifiée', 12),
  (3, '2026-05-19', '2026-06-13', 'En ligne (Teams)',      'Planifiée', 18),
  (4, '2026-05-26', '2026-06-27', 'Casablanca – Salle C',  'Planifiée', 20),
  (5, '2026-06-09', '2026-06-20', 'En ligne (Zoom)',       'Planifiée', 25),
  (6, '2026-06-16', '2026-07-10', 'Tanger – Salle D',      'Planifiée', 10);

INSERT INTO admins (username, email, mot_de_passe) VALUES
  ('admin', 'admin@formation.ma', '$2y$12$placeholder_hashed_password');

INSERT INTO avis (formation_id, stagiaire_id, note, commentaire) VALUES
  (1, 1, 5, 'Formation excellente, le formateur est très pédagogue !'),
  (2, 1, 4, 'Contenu très riche, parfait pour débuter en Data Science.');
