// ============================================
//  FormaPro Academy – app.js
// ============================================

const API = {
  formations:   'php/api_formations.php',
  auth:         'php/api_auth.php',
  inscriptions: 'php/api_inscriptions.php',
};

// ── État global ─────────────────────────────
const state = {
  user:       null,
  categories: [],
  currentPage: 1,
  currentCat:  0,
  currentNiveau: '',
  searchQuery: '',
};

// ── Utilitaires ─────────────────────────────
const $ = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);

function showToast(msg, type = 'info') {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || ''}</span><span>${msg}</span>`;
  toast.className = `toast ${type}`;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 3800);
}

async function apiFetch(url, params = {}, method = 'GET', body = null) {
  const qStr = new URLSearchParams(params).toString();
  const fullUrl = qStr ? `${url}?${qStr}` : url;
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(fullUrl, opts);
    return await res.json();
  } catch (e) {
    console.error('API error:', e);
    return { error: 'Erreur réseau.' };
  }
}

function starsHTML(note, total = 5) {
  note = Math.round(parseFloat(note) * 2) / 2;
  let html = '<div class="stars">';
  for (let i = 1; i <= total; i++) {
    html += `<span class="star ${i <= note ? '' : 'empty'}">★</span>`;
  }
  return html + '</div>';
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

function priceStr(prix) {
  return parseFloat(prix).toLocaleString('fr-MA', { minimumFractionDigits: 0 }) + ' MAD';
}

// ── Navbar scroll ────────────────────────────
function initNavbar() {
  const navbar = document.querySelector('.navbar');
  const hamburger = document.querySelector('.hamburger');
  const navLinks  = document.querySelector('.nav-links');

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  });

  hamburger?.addEventListener('click', () => {
    navLinks?.classList.toggle('open');
    hamburger.classList.toggle('active');
  });

  // Active link highlighting
  const sections = $$('section[id]');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        $$('.nav-links a').forEach(a => a.classList.remove('active'));
        const link = document.querySelector(`.nav-links a[href="#${e.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { threshold: .4 });
  sections.forEach(s => observer.observe(s));
}

// ── Stats hero ───────────────────────────────
async function loadStats() {
  const data = await apiFetch(API.formations, { action: 'stats' });
  if (data.error) return;
  const animate = (el, target) => {
    let current = 0;
    const step = target / 60;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.round(current) + (el.dataset.suffix || '');
      if (current >= target) clearInterval(timer);
    }, 25);
  };
  $$('[data-stat]').forEach(el => {
    const key = el.dataset.stat;
    if (data[key] !== undefined) animate(el, +data[key]);
  });
}

// ── Categories filter ────────────────────────
async function loadCategories() {
  const data = await apiFetch(API.formations, { action: 'categories' });
  if (data.error) return;
  state.categories = data;

  const bar = document.querySelector('.filter-bar');
  if (!bar) return;

  // "Tous" button
  bar.innerHTML = `<button class="filter-btn active" data-cat="0">
    <span>🎓</span> Toutes les formations
  </button>`;

  data.forEach(cat => {
    const icons = { code: '💻', shield: '🛡️', 'chart-bar': '📊', cloud: '☁️', users: '👥', palette: '🎨' };
    const btn = document.createElement('button');
    btn.className = 'filter-btn';
    btn.dataset.cat = cat.id;
    btn.innerHTML = `<span>${icons[cat.icone] || '📚'}</span> ${cat.nom} <small style="opacity:.6">(${cat.nb_formations})</small>`;
    bar.appendChild(btn);
  });

  bar.addEventListener('click', e => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    $$('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.currentCat  = +btn.dataset.cat;
    state.currentPage = 1;
    loadFormations();
  });
}

// ── Formations grid ───────────────────────────
async function loadFormations() {
  const grid = $('formations-grid');
  if (!grid) return;

  grid.innerHTML = '<div class="spinner"></div>';

  const params = {
    action:    'list',
    categorie: state.currentCat,
    niveau:    state.currentNiveau,
    search:    state.searchQuery,
    page:      state.currentPage,
    limit:     6,
  };

  const data = await apiFetch(API.formations, params);
  if (data.error || !data.data) {
    grid.innerHTML = '<p style="text-align:center;grid-column:1/-1">Aucune formation trouvée.</p>';
    return;
  }

  grid.innerHTML = data.data.map(f => cardFormationHTML(f)).join('');
  renderPagination(data);

  // Click → modal
  grid.querySelectorAll('.card-formation').forEach(card => {
    card.addEventListener('click', () => openFormationModal(+card.dataset.id));
  });
}

function cardFormationHTML(f) {
  const icons = ['💻','🛡️','📊','☁️','👥','🎨','📚'];
  const icon  = icons[f.categorie_id % icons.length] || '📚';
  const note  = parseFloat(f.note_moyenne || 0).toFixed(1);
  return `
  <div class="card-formation" data-id="${f.id}">
    <div class="card-img" style="background:linear-gradient(135deg,${f.cat_couleur || '#1B3F7A'}cc,${f.cat_couleur || '#1B3F7A'}88)">
      <span style="font-size:3.5rem;position:relative;z-index:1">${icon}</span>
      <div class="card-cat-badge">${f.categorie}</div>
      ${f.certifiante == 1 ? '<div class="cert-badge">✓ Certifiante</div>' : ''}
    </div>
    <div class="card-body">
      <div class="card-niveau">${f.niveau}</div>
      <div class="card-titre">${f.titre}</div>
      <div class="card-formateur">👤 ${f.formateur || 'À confirmer'}</div>
      <div class="card-meta">
        <div class="meta-item">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
          ${f.duree_heures}h de formation
        </div>
        <div class="meta-item">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          ${f.prochaine_session ? formatDate(f.prochaine_session) : 'Date à venir'}
        </div>
        ${f.nb_avis > 0 ? `<div class="meta-item">${starsHTML(note)} ${note} (${f.nb_avis})</div>` : ''}
      </div>
      <div class="card-footer">
        <div class="card-price">${priceStr(f.prix)} <span>TTC</span></div>
        <button class="btn btn-primary btn-sm">Voir détails</button>
      </div>
    </div>
  </div>`;
}

function renderPagination(data) {
  const wrap = $('pagination-wrap');
  if (!wrap || data.total_pages <= 1) { if (wrap) wrap.innerHTML = ''; return; }
  let html = '';
  if (state.currentPage > 1) html += `<button class="page-btn" data-page="${state.currentPage - 1}">‹</button>`;
  for (let i = 1; i <= data.total_pages; i++) {
    html += `<button class="page-btn ${i === state.currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
  }
  if (state.currentPage < data.total_pages) html += `<button class="page-btn" data-page="${state.currentPage + 1}">›</button>`;
  wrap.innerHTML = html;
  wrap.querySelectorAll('.page-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.currentPage = +btn.dataset.page;
      loadFormations();
      document.getElementById('formations')?.scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// ── Formation detail modal ────────────────────
async function openFormationModal(id) {
  const overlay = $('modal-overlay');
  const body    = $('modal-body');
  overlay.classList.add('open');
  body.innerHTML = '<div class="spinner"></div>';

  const f = await apiFetch(API.formations, { action: 'detail', id });
  if (f.error) { body.innerHTML = '<p>Formation introuvable.</p>'; return; }

  body.innerHTML = `
    <div style="display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <span style="background:rgba(27,63,122,.08);color:var(--primary);padding:.3rem .9rem;border-radius:50px;font-size:.8rem;font-weight:600">${f.categorie}</span>
      <span style="background:rgba(8,145,178,.08);color:var(--teal);padding:.3rem .9rem;border-radius:50px;font-size:.8rem;font-weight:600">${f.niveau}</span>
      ${f.certifiante == 1 ? '<span style="background:rgba(232,82,26,.1);color:var(--accent);padding:.3rem .9rem;border-radius:50px;font-size:.8rem;font-weight:600">✓ Formation certifiante</span>' : ''}
    </div>
    <p style="margin-bottom:1.5rem">${f.description || ''}</p>
    ${f.objectifs ? `<div style="background:var(--bg);border-radius:12px;padding:1.25rem;margin-bottom:1.5rem">
      <h4 style="color:var(--primary-dark);margin-bottom:.5rem">🎯 Objectifs</h4>
      <p style="font-size:.9rem">${f.objectifs}</p>
    </div>` : ''}
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.75rem">
      <div style="text-align:center;padding:1rem;background:var(--bg);border-radius:12px">
        <div style="font-size:1.4rem;font-family:var(--font-head);font-weight:800;color:var(--primary)">${f.duree_heures}h</div>
        <div style="font-size:.8rem;color:var(--muted)">Durée totale</div>
      </div>
      <div style="text-align:center;padding:1rem;background:var(--bg);border-radius:12px">
        <div style="font-size:1.4rem;font-family:var(--font-head);font-weight:800;color:var(--primary)">${f.places_max}</div>
        <div style="font-size:.8rem;color:var(--muted)">Places max</div>
      </div>
      <div style="text-align:center;padding:1rem;background:var(--bg);border-radius:12px">
        <div style="font-size:1.1rem;font-family:var(--font-head);font-weight:800;color:var(--accent)">${priceStr(f.prix)}</div>
        <div style="font-size:.8rem;color:var(--muted)">Prix TTC</div>
      </div>
    </div>
    ${f.sessions?.length > 0 ? `
    <h4 style="color:var(--primary-dark);margin-bottom:1rem">📅 Prochaines sessions</h4>
    <div style="display:flex;flex-direction:column;gap:.75rem;margin-bottom:1.75rem">
      ${f.sessions.map(s => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:1rem;border:2px solid var(--border);border-radius:12px;flex-wrap:wrap;gap:.75rem">
          <div>
            <div style="font-weight:600;font-size:.9rem;color:var(--primary-dark)">${formatDate(s.date_debut)} → ${formatDate(s.date_fin)}</div>
            <div style="font-size:.82rem;color:var(--muted)">📍 ${s.lieu} · ${s.places_restantes} place(s) restante(s)</div>
          </div>
          <button class="btn btn-primary btn-sm" onclick="inscrire(${s.id})" ${s.places_restantes < 1 ? 'disabled style="opacity:.5"' : ''}>
            ${s.places_restantes < 1 ? 'Complet' : "S'inscrire"}
          </button>
        </div>`).join('')}
    </div>` : '<p style="color:var(--muted);margin-bottom:1.5rem">Aucune session disponible pour le moment.</p>'}
    ${f.avis?.length > 0 ? `
    <h4 style="color:var(--primary-dark);margin-bottom:1rem">💬 Avis des stagiaires</h4>
    ${f.avis.map(a => `
      <div style="padding:1rem;border:1px solid var(--border);border-radius:12px;margin-bottom:.75rem">
        <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem">
          ${starsHTML(a.note)}
          <strong style="font-size:.85rem">${a.auteur}</strong>
          <span style="font-size:.75rem;color:var(--muted);margin-left:auto">${formatDate(a.created_at)}</span>
        </div>
        <p style="font-size:.87rem;margin:0;font-style:italic">"${a.commentaire}"</p>
      </div>`).join('')}` : ''}
  `;

  $('modal-title').textContent = f.titre;
}

// ── Inscription ───────────────────────────────
async function inscrire(sessionId) {
  if (!state.user) {
    openAuthModal();
    showToast('Connectez-vous pour vous inscrire.', 'info');
    return;
  }
  const res = await apiFetch(API.inscriptions, { action: 'inscrire' }, 'POST', { session_id: sessionId });
  if (res.error) { showToast(res.error, 'error'); return; }
  showToast(`Inscription confirmée ! Montant : ${priceStr(res.montant)}`, 'success');
}

// ── Formateurs ────────────────────────────────
function loadFormateurs() {
  const grid = $('formateurs-grid');
  if (!grid) return;

  const formateurs = [
    { prenom:'Karim',  nom:'Benali',   spec:'Développement Web Full-Stack', bio:'Expert React/Node.js, 10 ans d\'exp.' },
    { prenom:'Sanaa',  nom:'El Fassi', spec:'Data Science & IA',            bio:'PhD en IA, consultante senior.' },
    { prenom:'Youssef','nom':'Chraibi', spec:'Cybersécurité',               bio:'Certifié CISSP et CEH.' },
    { prenom:'Meryem', nom:'Tazi',     spec:'Cloud AWS & DevOps',           bio:'AWS Solutions Architect.' },
  ];

  grid.innerHTML = formateurs.map(f => {
    const initials = f.prenom[0] + f.nom[0];
    return `
    <div class="card-formateur">
      <div class="avatar">${initials}</div>
      <h3>${f.prenom} ${f.nom}</h3>
      <div class="spec">${f.spec}</div>
      <p>${f.bio}</p>
    </div>`;
  }).join('');
}

// ── Auth ──────────────────────────────────────
function openAuthModal() {
  $('auth-modal-overlay').classList.add('open');
}
function closeAuthModal() {
  $('auth-modal-overlay').classList.remove('open');
}

async function checkAuth() {
  const data = await apiFetch(API.auth, { action: 'me' });
  if (data.logged) {
    state.user = data;
    updateAuthUI(data);
  }
}

function updateAuthUI(user) {
  const navAuthEl = $('nav-auth');
  if (!navAuthEl) return;
  if (user) {
    navAuthEl.innerHTML = `
      <div style="display:flex;align-items:center;gap:.75rem">
        <div style="width:34px;height:34px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem">${user.prenom[0].toUpperCase()}</div>
        <span style="font-weight:500;color:var(--primary-dark)">${user.prenom}</span>
        <button class="btn btn-ghost btn-sm" onclick="logout()">Déconnexion</button>
      </div>`;
  } else {
    navAuthEl.innerHTML = `
      <button class="btn btn-ghost btn-sm" onclick="openAuthModal()">Connexion</button>
      <button class="btn btn-primary btn-sm" onclick="openAuthModal()">S'inscrire</button>`;
  }
}

async function logout() {
  await apiFetch(API.auth, { action: 'logout' });
  state.user = null;
  updateAuthUI(null);
  showToast('Déconnecté avec succès.', 'info');
}

function initAuthForm() {
  const tabBtns = $$('.auth-tab');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      $$('.auth-panel').forEach(p => p.style.display = 'none');
      $('panel-' + btn.dataset.tab).style.display = 'block';
    });
  });

  // Login form
  $('form-login')?.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.textContent = 'Connexion...'; btn.disabled = true;
    const data = await apiFetch(API.auth, { action: 'login' }, 'POST', {
      email: $('login-email').value,
      mot_de_passe: $('login-password').value,
    });
    btn.textContent = 'Se connecter'; btn.disabled = false;
    if (data.error) { showToast(data.error, 'error'); return; }
    state.user = data;
    updateAuthUI(data);
    closeAuthModal();
    showToast(`Bienvenue ${data.prenom} ! 👋`, 'success');
  });

  // Register form
  $('form-register')?.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.textContent = 'Inscription...'; btn.disabled = true;
    const data = await apiFetch(API.auth, { action: 'register' }, 'POST', {
      prenom:       $('reg-prenom').value,
      nom:          $('reg-nom').value,
      email:        $('reg-email').value,
      telephone:    $('reg-tel').value,
      entreprise:   $('reg-entreprise').value,
      mot_de_passe: $('reg-password').value,
    });
    btn.textContent = 'Créer mon compte'; btn.disabled = false;
    if (data.error) { showToast(data.error, 'error'); return; }
    state.user = data;
    updateAuthUI(data);
    closeAuthModal();
    showToast(`Compte créé ! Bienvenue ${data.prenom} 🎉`, 'success');
  });
}

// ── Contact form ──────────────────────────────
function initContactForm() {
  $('form-contact')?.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.textContent = 'Envoi...'; btn.disabled = true;
    const data = await apiFetch(API.inscriptions, { action: 'contact' }, 'POST', {
      nom:     $('contact-nom').value,
      email:   $('contact-email').value,
      sujet:   $('contact-sujet').value,
      message: $('contact-message').value,
    });
    btn.textContent = 'Envoyer le message'; btn.disabled = false;
    if (data.error) { showToast(data.error, 'error'); return; }
    showToast('Message envoyé ! Nous vous répondrons sous 24h. ✉️', 'success');
    e.target.reset();
  });
}

// ── Search ────────────────────────────────────
function initSearch() {
  $('search-input')?.addEventListener('input', e => {
    clearTimeout(window._searchTimer);
    window._searchTimer = setTimeout(() => {
      state.searchQuery = e.target.value.trim();
      state.currentPage = 1;
      loadFormations();
    }, 380);
  });

  $('niveau-select')?.addEventListener('change', e => {
    state.currentNiveau = e.target.value;
    state.currentPage   = 1;
    loadFormations();
  });
}

// ── Smooth scroll CTA ─────────────────────────
function initScrollBtns() {
  $$('[data-scroll]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.querySelector(btn.dataset.scroll);
      target?.scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// ── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  initNavbar();
  initScrollBtns();
  loadStats();
  await loadCategories();
  loadFormations();
  loadFormateurs();
  checkAuth();
  initAuthForm();
  initContactForm();
  initSearch();

  // Modal close
  $('modal-overlay')?.addEventListener('click', e => {
    if (e.target === $('modal-overlay')) $('modal-overlay').classList.remove('open');
  });
  $('modal-close')?.addEventListener('click', () => $('modal-overlay').classList.remove('open'));
  $('auth-modal-overlay')?.addEventListener('click', e => {
    if (e.target === $('auth-modal-overlay')) closeAuthModal();
  });
  $('auth-modal-close')?.addEventListener('click', closeAuthModal);
});
