<?php
// ============================================
//  config.php – Configuration générale
// ============================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'centre_formation');
define('DB_USER', 'root');         // ← modifier selon votre config
define('DB_PASS', '');             // ← modifier selon votre config
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'FormaPro Academy');
define('SITE_URL',  'http://localhost/formation');
define('SITE_EMAIL','contact@formapro.ma');

define('UPLOAD_DIR', __DIR__ . '/assets/uploads/');
define('SESSION_LIFETIME', 3600); // 1 heure

// Démarrage de session sécurisée
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => false,   // true en HTTPS
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// ============================================
//  Connexion PDO
// ============================================
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Connexion base de données impossible.']));
        }
    }
    return $pdo;
}

// ============================================
//  Helpers utilitaires
// ============================================
function sanitize(string $val): string {
    return htmlspecialchars(trim($val), ENT_QUOTES, 'UTF-8');
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function isLoggedIn(): bool {
    return isset($_SESSION['stagiaire_id']);
}

function isAdmin(): bool {
    return isset($_SESSION['admin_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.html');
        exit;
    }
}
