<?php
// ============================================
//  api_formations.php – API REST Formations
// ============================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

switch ($action) {

    // ── Lister toutes les formations ──────────────────
    case 'list':
        $categorie = (int)($_GET['categorie'] ?? 0);
        $niveau    = sanitize($_GET['niveau'] ?? '');
        $search    = sanitize($_GET['search'] ?? '');
        $limit     = min((int)($_GET['limit'] ?? 6), 50);
        $page      = max((int)($_GET['page']  ?? 1), 1);
        $offset    = ($page - 1) * $limit;

        $where  = ['f.active = 1'];
        $params = [];

        if ($categorie > 0) { $where[] = 'f.categorie_id = ?'; $params[] = $categorie; }
        if ($niveau)        { $where[] = 'f.niveau = ?';       $params[] = $niveau;    }
        if ($search)        { $where[] = 'f.titre LIKE ?';     $params[] = "%$search%"; }

        $whereSQL = implode(' AND ', $where);
        $db = getDB();

        // Total pour pagination
        $countStmt = $db->prepare("SELECT COUNT(*) FROM formations f WHERE $whereSQL");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        // Requête principale
        $sql = "
            SELECT f.id, f.titre, f.description, f.duree_heures, f.prix, f.niveau,
                   f.places_max, f.certifiante, f.image_url,
                   c.nom AS categorie, c.couleur AS cat_couleur, c.icone AS cat_icone,
                   CONCAT(fo.prenom, ' ', fo.nom) AS formateur,
                   COALESCE(AVG(a.note), 0) AS note_moyenne,
                   COUNT(DISTINCT a.id) AS nb_avis,
                   (SELECT MIN(s.date_debut)
                    FROM sessions s
                    WHERE s.formation_id = f.id AND s.statut = 'Planifiée'
                      AND s.date_debut >= CURDATE()) AS prochaine_session
            FROM formations f
            JOIN categories c ON c.id = f.categorie_id
            LEFT JOIN formateurs fo ON fo.id = f.formateur_id
            LEFT JOIN avis a ON a.formation_id = f.id
            WHERE $whereSQL
            GROUP BY f.id
            ORDER BY prochaine_session ASC, f.id DESC
            LIMIT ? OFFSET ?
        ";
        $params[] = $limit;
        $params[] = $offset;

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $formations = $stmt->fetchAll();

        jsonResponse([
            'data'        => $formations,
            'total'       => $total,
            'page'        => $page,
            'total_pages' => ceil($total / $limit),
        ]);

    // ── Détail d'une formation ────────────────────────
    case 'detail':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['error' => 'ID manquant'], 400);

        $db = getDB();
        $stmt = $db->prepare("
            SELECT f.*, c.nom AS categorie, c.couleur AS cat_couleur,
                   fo.prenom AS form_prenom, fo.nom AS form_nom,
                   fo.bio AS form_bio, fo.specialite AS form_specialite,
                   COALESCE(AVG(a.note), 0) AS note_moyenne,
                   COUNT(DISTINCT a.id) AS nb_avis
            FROM formations f
            JOIN categories c ON c.id = f.categorie_id
            LEFT JOIN formateurs fo ON fo.id = f.formateur_id
            LEFT JOIN avis a ON a.formation_id = f.id
            WHERE f.id = ? AND f.active = 1
            GROUP BY f.id
        ");
        $stmt->execute([$id]);
        $formation = $stmt->fetch();
        if (!$formation) jsonResponse(['error' => 'Formation introuvable'], 404);

        // Sessions disponibles
        $sessStmt = $db->prepare("
            SELECT * FROM sessions
            WHERE formation_id = ? AND statut = 'Planifiée' AND date_debut >= CURDATE()
            ORDER BY date_debut ASC
        ");
        $sessStmt->execute([$id]);
        $formation['sessions'] = $sessStmt->fetchAll();

        // Avis récents
        $avisStmt = $db->prepare("
            SELECT a.note, a.commentaire, a.created_at,
                   CONCAT(s.prenom, ' ', LEFT(s.nom,1), '.') AS auteur
            FROM avis a
            JOIN stagiaires s ON s.id = a.stagiaire_id
            WHERE a.formation_id = ?
            ORDER BY a.created_at DESC LIMIT 5
        ");
        $avisStmt->execute([$id]);
        $formation['avis'] = $avisStmt->fetchAll();

        jsonResponse($formation);

    // ── Catégories ───────────────────────────────────
    case 'categories':
        $db = getDB();
        $stmt = $db->query("
            SELECT c.*, COUNT(f.id) AS nb_formations
            FROM categories c
            LEFT JOIN formations f ON f.categorie_id = c.id AND f.active = 1
            GROUP BY c.id ORDER BY c.nom
        ");
        jsonResponse($stmt->fetchAll());

    // ── Statistiques accueil ─────────────────────────
    case 'stats':
        $db = getDB();
        $stats = [];
        $stats['nb_formations'] = $db->query("SELECT COUNT(*) FROM formations WHERE active=1")->fetchColumn();
        $stats['nb_stagiaires'] = $db->query("SELECT COUNT(*) FROM stagiaires WHERE actif=1")->fetchColumn();
        $stats['nb_formateurs'] = $db->query("SELECT COUNT(*) FROM formateurs WHERE actif=1")->fetchColumn();
        $stats['nb_certifiantes']= $db->query("SELECT COUNT(*) FROM formations WHERE certifiante=1 AND active=1")->fetchColumn();
        jsonResponse($stats);

    default:
        jsonResponse(['error' => 'Action inconnue'], 400);
}
