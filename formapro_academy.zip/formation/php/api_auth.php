<?php
// ============================================
//  api_auth.php – Inscription / Connexion
// ============================================
require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? $_POST;

switch ($action) {

    // ── Inscription stagiaire ─────────────────────────
    case 'register':
        $required = ['prenom','nom','email','mot_de_passe'];
        foreach ($required as $f) {
            if (empty($input[$f])) jsonResponse(['error' => "Champ '$f' requis."], 422);
        }

        $email = filter_var(trim($input['email']), FILTER_VALIDATE_EMAIL);
        if (!$email) jsonResponse(['error' => 'Email invalide.'], 422);

        $password = $input['mot_de_passe'];
        if (strlen($password) < 8) jsonResponse(['error' => 'Mot de passe trop court (8 caractères min).'], 422);

        $db = getDB();
        $check = $db->prepare("SELECT id FROM stagiaires WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) jsonResponse(['error' => 'Email déjà utilisé.'], 409);

        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $stmt = $db->prepare("
            INSERT INTO stagiaires (prenom, nom, email, telephone, entreprise, mot_de_passe)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            sanitize($input['prenom']),
            sanitize($input['nom']),
            $email,
            sanitize($input['telephone'] ?? ''),
            sanitize($input['entreprise'] ?? ''),
            $hash,
        ]);
        $id = $db->lastInsertId();
        $_SESSION['stagiaire_id']  = $id;
        $_SESSION['stagiaire_nom'] = sanitize($input['prenom']);

        jsonResponse(['success' => true, 'id' => $id, 'prenom' => sanitize($input['prenom'])]);

    // ── Connexion stagiaire ───────────────────────────
    case 'login':
        $email    = filter_var(trim($input['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $password = $input['mot_de_passe'] ?? '';

        if (!$email || !$password) jsonResponse(['error' => 'Email et mot de passe requis.'], 422);

        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM stagiaires WHERE email = ? AND actif = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['mot_de_passe'])) {
            jsonResponse(['error' => 'Identifiants incorrects.'], 401);
        }

        $_SESSION['stagiaire_id']  = $user['id'];
        $_SESSION['stagiaire_nom'] = $user['prenom'];

        jsonResponse(['success' => true, 'prenom' => $user['prenom'], 'id' => $user['id']]);

    // ── Déconnexion ───────────────────────────────────
    case 'logout':
        session_destroy();
        jsonResponse(['success' => true]);

    // ── Statut session ────────────────────────────────
    case 'me':
        if (isLoggedIn()) {
            jsonResponse(['logged' => true, 'prenom' => $_SESSION['stagiaire_nom'], 'id' => $_SESSION['stagiaire_id']]);
        }
        jsonResponse(['logged' => false]);

    default:
        jsonResponse(['error' => 'Action inconnue'], 400);
}
