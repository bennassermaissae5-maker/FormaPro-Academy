<?php
// ============================================
//  api_inscriptions.php – Gestion inscriptions
// ============================================
require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? $_POST;

switch ($action) {

    // ── Créer une inscription ─────────────────────────
    case 'inscrire':
        requireLogin();
        $session_id = (int)($input['session_id'] ?? 0);
        if (!$session_id) jsonResponse(['error' => 'Session ID requis.'], 422);

        $db = getDB();

        // Vérifier places disponibles
        $sess = $db->prepare("SELECT * FROM sessions WHERE id = ? AND statut = 'Planifiée' AND places_restantes > 0");
        $sess->execute([$session_id]);
        $session = $sess->fetch();
        if (!$session) jsonResponse(['error' => 'Session indisponible ou complète.'], 409);

        // Récupérer le prix de la formation
        $prix = $db->prepare("SELECT prix FROM formations WHERE id = ?");
        $prix->execute([$session['formation_id']]);
        $montant = (float)($prix->fetchColumn() ?? 0);

        // Double inscription ?
        $exist = $db->prepare("SELECT id FROM inscriptions WHERE stagiaire_id = ? AND session_id = ?");
        $exist->execute([$_SESSION['stagiaire_id'], $session_id]);
        if ($exist->fetch()) jsonResponse(['error' => 'Vous êtes déjà inscrit à cette session.'], 409);

        $db->beginTransaction();
        try {
            $ins = $db->prepare("
                INSERT INTO inscriptions (stagiaire_id, session_id, statut, paiement, montant)
                VALUES (?, ?, 'Confirmée', 'Non payé', ?)
            ");
            $ins->execute([$_SESSION['stagiaire_id'], $session_id, $montant]);

            $upd = $db->prepare("UPDATE sessions SET places_restantes = places_restantes - 1 WHERE id = ?");
            $upd->execute([$session_id]);

            $db->commit();
            jsonResponse(['success' => true, 'message' => 'Inscription confirmée !', 'montant' => $montant]);
        } catch (Exception $e) {
            $db->rollBack();
            jsonResponse(['error' => 'Erreur lors de l\'inscription.'], 500);
        }

    // ── Mes inscriptions ──────────────────────────────
    case 'mes_inscriptions':
        requireLogin();
        $db   = getDB();
        $stmt = $db->prepare("
            SELECT i.*, f.titre AS formation, f.image_url,
                   s.date_debut, s.date_fin, s.lieu, s.statut AS session_statut,
                   c.nom AS categorie, c.couleur AS cat_couleur
            FROM inscriptions i
            JOIN sessions s ON s.id = i.session_id
            JOIN formations f ON f.id = s.formation_id
            JOIN categories c ON c.id = f.categorie_id
            WHERE i.stagiaire_id = ?
            ORDER BY s.date_debut DESC
        ");
        $stmt->execute([$_SESSION['stagiaire_id']]);
        jsonResponse($stmt->fetchAll());

    // ── Contact ───────────────────────────────────────
    case 'contact':
        $nom     = sanitize($input['nom']     ?? '');
        $email   = filter_var(trim($input['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $sujet   = sanitize($input['sujet']   ?? '');
        $message = sanitize($input['message'] ?? '');

        if (!$nom || !$email || !$message) jsonResponse(['error' => 'Champs requis manquants.'], 422);

        $db   = getDB();
        $stmt = $db->prepare("INSERT INTO contacts (nom, email, sujet, message) VALUES (?,?,?,?)");
        $stmt->execute([$nom, $email, $sujet, $message]);

        jsonResponse(['success' => true, 'message' => 'Message envoyé avec succès !']);

    default:
        jsonResponse(['error' => 'Action inconnue'], 400);
}
